﻿import React from 'react';

export function AdminSubMenu1() {
  return <div>SubMenu 1 Content</div>;
};

export default AdminSubMenu1;